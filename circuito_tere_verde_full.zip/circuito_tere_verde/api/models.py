
from django.db import models

class Parque(models.Model):
    nome = models.CharField(max_length=150)
    descricao = models.TextField()
    localizacao = models.CharField(max_length=200)

    def __str__(self):
        return self.nome

class Trilha(models.Model):
    parque = models.ForeignKey(Parque, on_delete=models.CASCADE)
    nome = models.CharField(max_length=150)
    dificuldade = models.CharField(max_length=50)
    distancia_km = models.FloatField()
    descricao = models.TextField()

    def __str__(self):
        return self.nome

class Evento(models.Model):
    parque = models.ForeignKey(Parque, on_delete=models.CASCADE)
    titulo = models.CharField(max_length=150)
    data = models.DateField()
    descricao = models.TextField()

    def __str__(self):
        return self.titulo

class Biodiversidade(models.Model):
    parque = models.ForeignKey(Parque, on_delete=models.CASCADE)
    especie = models.CharField(max_length=150)
    categoria = models.CharField(max_length=100)  # flora / fauna
    descricao = models.TextField()

    def __str__(self):
        return self.especie
