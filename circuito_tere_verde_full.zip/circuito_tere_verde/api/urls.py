
from django.urls import path
from rest_framework import routers
from .views import (
    ParquePublicView, TrilhaPublicView, EventoPublicView, BiodiversidadePublicView,
    ParqueAdminView, TrilhaAdminView, EventoAdminView, BiodiversidadeAdminView
)

router = routers.DefaultRouter()
router.register("public/parques", ParquePublicView)
router.register("public/trilhas", TrilhaPublicView)
router.register("public/eventos", EventoPublicView)
router.register("public/biodiversidade", BiodiversidadePublicView)

router.register("admin/parques", ParqueAdminView)
router.register("admin/trilhas", TrilhaAdminView)
router.register("admin/eventos", EventoAdminView)
router.register("admin/biodiversidade", BiodiversidadeAdminView)

urlpatterns = router.urls
