
from rest_framework import serializers
from .models import Parque, Trilha, Evento, Biodiversidade

class ParqueSerializer(serializers.ModelSerializer):
    class Meta:
        model = Parque
        fields = "__all__"

class TrilhaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trilha
        fields = "__all__"

class EventoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evento
        fields = "__all__"

class BiodiversidadeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Biodiversidade
        fields = "__all__"
