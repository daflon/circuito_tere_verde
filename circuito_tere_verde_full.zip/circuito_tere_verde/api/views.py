
from rest_framework import viewsets, permissions
from .models import Parque, Trilha, Evento, Biodiversidade
from .serializers import ParqueSerializer, TrilhaSerializer, EventoSerializer, BiodiversidadeSerializer

class BasePublicViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.AllowAny]

class BaseAdminViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAdminUser]

# Public
class ParquePublicView(BasePublicViewSet):
    queryset = Parque.objects.all()
    serializer_class = ParqueSerializer

class TrilhaPublicView(BasePublicViewSet):
    queryset = Trilha.objects.all()
    serializer_class = TrilhaSerializer

class EventoPublicView(BasePublicViewSet):
    queryset = Evento.objects.all()
    serializer_class = EventoSerializer

class BiodiversidadePublicView(BasePublicViewSet):
    queryset = Biodiversidade.objects.all()
    serializer_class = BiodiversidadeSerializer

# Admin
class ParqueAdminView(BaseAdminViewSet):
    queryset = Parque.objects.all()
    serializer_class = ParqueSerializer

class TrilhaAdminView(BaseAdminViewSet):
    queryset = Trilha.objects.all()
    serializer_class = TrilhaSerializer

class EventoAdminView(BaseAdminViewSet):
    queryset = Evento.objects.all()
    serializer_class = EventoSerializer

class BiodiversidadeAdminView(BaseAdminViewSet):
    queryset = Biodiversidade.objects.all()
    serializer_class = BiodiversidadeSerializer
