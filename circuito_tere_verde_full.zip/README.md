
# Circuito Terê Verde - MVP Backend
API completa com Django + DRF + JWT.
